#!/usr/bin/env python3
"""Generate a chat-bar client demo video (HyperFrames) from config.json.

Usage:  python3 build.py [config.json]   then   npx hyperframes check
Everything time-related lives here: scene windows, typing runs, click beats and the
<audio> SFX tags are all derived from the same numbers so picture and sound cannot drift.
Edit config.json (or the SCENES library below), never index.html (it is overwritten).
"""
import json, re, subprocess, sys, os, html as H
HERE = os.path.dirname(os.path.abspath(__file__))
cfg = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'config.json'))

# ------------------------------------------------------------------ palette
pal = cfg.get('palette', {})
accent = pal.get('accent', '#6d3ee0'); accent_text = pal.get('accent_text', accent)
accent2 = pal.get('accent_soft', '#a78bfa'); turn = pal.get('turn', accent)
def rgba(hexc, a):
    h = hexc.lstrip('#'); r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f'rgba({r},{g},{b},{a})'
style = open(os.path.join(HERE, 'styles.css')).read()
style = re.sub(r'--red:#[0-9a-fA-F]{6}; --red-text:#[0-9a-fA-F]{6};', f'--red:{accent}; --red-text:{accent_text};', style, count=1)
style = style.replace('--turn:#6d3ee0;', f'--turn:{turn};')
style = re.sub(r'linear-gradient\(135deg,var\(--red\),#[0-9a-fA-F]{6}\)', f'linear-gradient(135deg,var(--red),{accent2})', style)
style = re.sub(r'#bloom-red\{background:radial-gradient\([^}]*\}', f'#bloom-red{{background:radial-gradient(circle,{rgba(accent,.22)} 0%,{rgba(accent,.10)} 35%,{rgba(accent,0)} 70%);}}', style)
style = re.sub(r'#bloom-red2\{background:radial-gradient\([^}]*\}', f'#bloom-red2{{background:radial-gradient(circle,{rgba(accent2,.14)} 0%,{rgba(accent2,0)} 70%);}}', style)
if 'bloom_secondary' in pal:
    s2 = pal['bloom_secondary']
    style = re.sub(r'#bloom-violet\{background:radial-gradient\([^}]*\}', f'#bloom-violet{{background:radial-gradient(circle,{rgba(s2,.16)} 0%,{rgba(s2,.07)} 35%,{rgba(s2,0)} 70%);}}', style)


# ------------------------------------------------------------------ contrast guard (white text sits on `turn`; white badge text sits on `accent`)
def _lum(hexc):
    h = hexc.lstrip('#'); c = [int(h[k:k+2], 16)/255 for k in (0, 2, 4)]
    c = [v/12.92 if v <= .03928 else ((v+.055)/1.055)**2.4 for v in c]
    return .2126*c[0] + .7152*c[1] + .0722*c[2]
for label, col in (('palette.turn', turn), ('palette.accent', accent)):
    ratio = 1.05 / (_lum(col) + .05)
    if ratio < 4.5:
        print(f'WARNING: white text on {label} {col} is {ratio:.2f}:1, needs 4.5:1. Pick a darker shade (about 25% darker) or `npx hyperframes check` will flag contrast.')

# ------------------------------------------------------------------ brand lockup
client = cfg['client']; brain = cfg.get('brain_label', f"{client['short']} Brain")
def wordmark(idp, white):
    if client.get('logo'):
        cls = ' style="filter:brightness(0) invert(1)"' if white else ''
        return f'<img class="xc" id="{idp}-wm" src="{client["logo"]}" alt="{H.escape(client["name"])}"{cls} />'
    sub = f'<span>{H.escape(client.get("wordmark_sub",""))}</span>' if client.get('wordmark_sub') else ''
    return f'<div class="wordmark" id="{idp}-wm"><b>{H.escape(client.get("wordmark", client["short"]))}</b>{sub}</div>'
def lockup(idp, white=False, eyebrow=''):
    end = '-end' if white else ''
    return (f'<div class="lockup{" white" if white else ""}" id="{idp}">{eyebrow}{wordmark(idp, white)}'
            f'<div class="rule" id="{idp}-rule"></div><div class="with" id="{idp}-with">with</div>'
            f'<div class="wh" id="{idp}-wh"><img src="assets/whitehorse-mark-white{end}.png" alt="" /><span>Whitehorse AI</span></div></div>')
send_btn = lambda i: (f'<div class="foot"><div class="brain">{H.escape(brain)}</div><div class="send" id="{i}">'
    '<svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg></div></div>')

# ------------------------------------------------------------------ scene library
def headline(idp, text):
    return f'<div class="head"><div class="headline" id="{idp}"><span class="w">' + '</span><span class="w">'.join(H.escape(w) for w in text.split()) + '</span></div></div>'
def scene_im(i, sc):
    addr = H.escape(sc.get('address', '120 Harbour Street'))
    m = f'''<div class="fan">
      <div class="doc" id="im3" data-layout-allow-overlap data-layout-allow-occlusion><div class="tag" data-layout-allow-overlap data-layout-allow-occlusion>Key facts</div><div class="dh"></div><div class="dl"></div><div class="dl m"></div>{''.join(f'<div class="kv" data-layout-allow-overlap data-layout-allow-occlusion><b>{H.escape(a)}</b><span>{H.escape(b)}</span></div>' for a,b in sc.get('facts', [["Scope","3 workstreams"],["Timeline","6 weeks"]]))}<div class="dl xs"></div></div>
      <div class="doc" id="im2" data-layout-allow-overlap data-layout-allow-occlusion><div class="tag" data-layout-allow-overlap data-layout-allow-occlusion>Floor plan</div><div class="dh"></div><div class="plan"></div><div class="dl"></div><div class="dl s"></div></div>
      <div class="doc" id="im1" data-layout-allow-overlap data-layout-allow-occlusion><div class="img red"></div><div class="tag" data-layout-allow-overlap data-layout-allow-occlusion>{H.escape(sc.get('doc_label','Proposal'))}</div><div class="title" data-layout-allow-overlap data-layout-allow-occlusion>{addr}</div><div class="sub" data-layout-allow-overlap data-layout-allow-occlusion>{H.escape(sc.get('sub','Prepared for the client, ready for review'))}</div><div class="dl"></div><div class="dl m"></div></div>
    </div>'''
    j = f'''const im1 = document.getElementById('im1'), im2 = document.getElementById('im2'), im3 = document.getElementById('im3');
[im1,im2,im3].forEach((el,k) => tl.fromTo(el, {{ y: 30, x: 900, opacity: 0, rotate: 0 }}, {{ x: 0, y: 30, opacity: 1, duration: .55, ease: 'power4.out' }}, S{i} + .03 + k*.06));
tl.to(im2, {{ x: -330, rotate: -7, y: 60, duration: .6, ease: 'power3.inOut' }}, S{i} + .75);
tl.to(im3, {{ x:  330, rotate:  7, y: 60, duration: .6, ease: 'power3.inOut' }}, S{i} + .75);
fillDoc(im1, S{i} + .3, .05); fillDoc(im2, S{i} + .8, .05); fillDoc(im3, S{i} + .85, .05);'''
    return m, j, [('whoosh', .05, .45), ('pop', .9, .5)]
def scene_emails(i, sc):
    groups = sc.get('groups', [["Needs you","4","red",[["Sarah Chen","Re: proposal, can we talk Friday?"],["Website enquiry","New lead: 120 Harbour Street"],["Board","Quarterly meeting agenda"],["Marcus Reid","Invoice query, job 1042"]]],["Handled","2","violet",[["Jenna Lo","Booking confirmed for Thursday"],["Tom Walsh","Access issue, building manager notified"]]],["Reports, filed","2","soft",[["Accounting","Weekly summary"],["Industry news","Market update, Q3"]]]])
    g = ''.join(f'<div class="grp"><div class="gh {c}"><b>{H.escape(n)}</b><span>{k}</span></div>' + ''.join(f'<div class="em sm"><span class="ef">{H.escape(f)}</span><span class="es">{H.escape(s)}</span></div>' for f, s in rows) + '</div>' for n, k, c, rows in groups)
    m = f'<div class="mailwin c" id="mw"><div class="mh"><b>Inbox</b><span class="tag">{H.escape(sc.get("count_label","4 need you"))}</span></div><div class="mlist sorted" id="inb-sorted">{g}</div></div>'
    j = f'''gsap.set('#mw', {{ opacity: 0 }});
tl.fromTo('#mw', {{ opacity: 0, y: -700 }}, {{ opacity: 1, y: 0, duration: .6, ease: 'power3.out' }}, S{i} + .03);
document.querySelectorAll('#inb-sorted .gh').forEach((el,k) => {{ tl.set(el, {{ opacity: 1, y: 40 }}, S{i} + .35 + k*.16); tl.to(el, {{ y: 0, duration: .3, ease: 'power4.out' }}, S{i} + .35 + k*.16); }});
document.querySelectorAll('#inb-sorted .em.sm').forEach((el,k) => tl.fromTo(el, {{ opacity: 0, x: -14 }}, {{ opacity: 1, x: 0, duration: .3, ease: 'power2.out' }}, S{i} + .45 + k*.06));'''
    return m, j, [('whoosh', .05, .45), ('pop', .8, .5)]
def scene_inbox(i, sc):
    rows = sc.get('rows', [["JL","Jenna Lo","Unit 4","Leaking tap in the kitchenette","Plumber contacted"],["MR","Marcus Reid","Level 2","Air con not cooling since Monday","Work order raised"],["PA","Priya Anand","Ground","Car park light out, bay 12","Electrician contacted"],["TW","Tom Walsh","Level 5","Access card stopped working","Manager notified"],["HK","Hannah Kim","Unit 9","Follow up: door closer","Customer replied, closed"]])
    r = ''.join(f'<div class="mail"><span class="av">{a}</span><span class="from">{H.escape(f)}<small>{H.escape(u)}</small></span><span class="subj">{H.escape(s)}</span><span class="st"><span class="g"></span>{H.escape(st)}</span></div>' for a, f, u, s, st in rows)
    m = f'<div class="inbox c" id="ib"><div class="ih"><b>{H.escape(sc.get("title","Requests"))}</b><span class="tag">{H.escape(sc.get("tag","Inbox, this morning"))}</span></div>{r}</div>'
    j = f'''gsap.set('#ib', {{ opacity: 0 }});
tl.fromTo('#ib', {{ opacity: 0, y: 520 }}, {{ opacity: 1, y: 0, duration: .6, ease: 'power4.out' }}, S{i} + .03);
document.querySelectorAll('#ib .mail').forEach((el,k) => {{
  tl.fromTo(el, {{ opacity: 0, x: -20 }}, {{ opacity: 1, x: 0, duration: .3, ease: 'power2.out' }}, S{i} + .3 + k*.08);
  tl.fromTo(el.querySelector('.st'), {{ opacity: 0, scale: .9 }}, {{ opacity: 1, scale: 1, duration: .35, ease: 'back.out(2)' }}, S{i} + .8 + k*.14);
}});'''
    return m, j, [('whoosh', .05, .45)] + [('pop', .8 + k*.14, .4) for k in range(len(rows))]
def scene_voice_crm(i, sc):
    fields = sc.get('fields', [["Contact","Sarah Chen"],["Company","Harbour Street Co."],["Need","New proposal"],["Task","Follow up Friday"]])
    f = ''.join(f'<div class="field"{" style=\"border-bottom:0\"" if k == len(fields)-1 else ""}><span class="k">{H.escape(a)}</span><span class="v{" pill" if k==2 else ""}">{H.escape(b)}</span></div>' for k, (a, b) in enumerate(fields))
    m = f'''<div class="phone c" id="ph6"><div class="notch"></div><div class="to"><span class="av">{H.escape(sc.get('agent','Assistant')[0])}</span>{H.escape(sc.get('agent','Assistant'))}</div><div class="memo"><div class="wave" id="wave6"></div><div class="t" id="w6-t">0:00 voice memo</div></div><div class="transcript"><span id="a3-text"></span></div><div class="simba"><span class="dot"></span>{H.escape(sc.get('agent','Assistant'))} is listening</div></div>
    <div class="vault c" id="v7"><div class="tick" id="tick7"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg></div><div class="vh"><b>New contact</b><span class="tag">{H.escape(sc.get('crm','CRM'))}</span></div>{f}</div>'''
    transcript = json.dumps(sc.get('transcript', 'Met Sarah Chen from Harbour Street Co., wants a proposal, follow up Friday.'))
    j = f'''gsap.set(['#ph6','#v7'], {{ opacity: 0 }});
tl.fromTo('#ph6', {{ opacity: 0, y: 120, rotate: -2 }}, {{ opacity: 1, y: 0, rotate: 0, duration: .55, ease: 'power3.out' }}, S{i} + .03);
(function wave(){{
  const w = document.getElementById('wave6'); const bars = [];
  for (let k=0;k<26;k++){{ const b=document.createElement('i'); w.appendChild(b); bars.push(b); }}
  const d = {{ p: 0 }}; const t0 = S{i} + .3, dur = 1.5;
  tl.to(d, {{ p: dur, duration: dur, ease: 'none', onUpdate: () => {{
    bars.forEach((b,k) => {{ const s = .18 + .82 * Math.abs(Math.sin(d.p*7 + k*.9) * Math.sin(d.p*3.1 + k*.37)); b.style.transform = `scaleY(${{s.toFixed(3)}})`; }});
    document.getElementById('w6-t').textContent = `0:0${{Math.floor(d.p)}} voice memo`;
  }}}}, t0);
  tl.to(bars, {{ scaleY: .2, duration: .3, ease: 'power2.out' }}, t0 + dur);
}})();
typeInto('a3-text', {transcript}, S{i} + .35, 60);
tl.fromTo('#v7', {{ opacity: 1, clipPath: 'inset(0 100% 0 0 round 24px)' }}, {{ opacity: 1, clipPath: 'inset(0 0% 0 0 round 24px)', duration: .55, ease: 'power3.out' }}, S{i} + .55);
tl.set('#v7', {{ clipPath: 'none' }}, S{i} + 1.12); // release the mask or the tick badge outside the card gets trimmed
document.querySelectorAll('#v7 .field .v').forEach((el,k) => tl.fromTo(el, {{ opacity: 0, x: -16 }}, {{ opacity: 1, x: 0, duration: .3, ease: 'power2.out' }}, S{i} + .8 + k*.15));
tl.to('#tick7', {{ opacity: 1, scale: 1, duration: .4, ease: 'back.out(2.4)' }}, S{i} + 1.5);'''
    return m, j, [('whoosh', .05, .45), ('pop', .6, .5), ('pop', .9, .5), ('chime', 1.5, .5)]
def scene_doc_pair(i, sc):
    left, right = sc.get('left', {}), sc.get('right', {})
    def rows(tbl): return ''.join(f'<div class="row{" h" if k==0 else ""}">' + ''.join(f'<span>{H.escape(c)}</span>' for c in r) + '</div>' for k, r in enumerate(tbl))
    tbl = left.get('table', [["Item","Qty","Amount"],["Discovery workshop","1","$2,400"],["Build, three workflows","3","$18,000"],["Training, half day","1","$1,600"]])
    cl = right.get('clauses', [["1.0","Scope","Three workflows, agreed list"],["2.0","Term","Six weeks from kickoff"],["3.0","Fee","Fixed, paid in two parts"],["4.0","Support","30 days after handover"]])
    m = f'''<div class="split">
      <div class="doc" id="sub5"><div class="tag">{H.escape(left.get('tag','Proposal'))}</div><div class="title">{H.escape(left.get('title','120 Harbour Street'))}</div><div class="sub">{H.escape(left.get('sub','Scope and pricing'))}</div><div class="tbl">{rows(tbl)}</div></div>
      <div class="doc" id="hoa5"><div class="tag">{H.escape(right.get('tag','Agreement'))}</div><div class="title">{H.escape(right.get('title','Terms, Harbour Street Co.'))}</div><div class="sub">{H.escape(right.get('sub','Non-binding summary'))}</div><div class="clauses">{''.join(f'<div class="clause"><i>{n}</i><div>{H.escape(a)} <span>{H.escape(b)}</span></div></div>' for n,a,b in cl)}</div></div>
    </div>'''
    j = f'''tl.fromTo('#sub5', {{ x: -520, rotateY: 21, opacity: 0 }}, {{ x: 0, rotateY: 9, opacity: 1, duration: .7, ease: 'power3.out' }}, S{i} + .05);
tl.fromTo('#hoa5', {{ x:  520, rotateY: -21, opacity: 0 }}, {{ x: 0, rotateY: -9, opacity: 1, duration: .7, ease: 'power3.out' }}, S{i} + .15);
document.querySelectorAll('#sub5 .row').forEach((el,k) => tl.to(el, {{ opacity: 1, duration: .3 }}, S{i} + .6 + k*.08));
document.querySelectorAll('#hoa5 .clause').forEach((el,k) => tl.to(el, {{ opacity: 1, duration: .3 }}, S{i} + .7 + k*.08));'''
    return m, j, [('whoosh', .05, .45), ('pop', .15, .5)]
def scene_quote(i, sc):
    """A single document with line items and a total. Generic: quotes, invoices, proposals, work orders."""
    items = sc.get('items', [["Site visit and assessment","1","$180"],["Replace hot water unit, 250L","1","$1,940"],["Labour, two technicians","4 hrs","$560"],["Compliance certificate","1","$95"]])
    rows = ''.join(f'<div class="row"><span>{H.escape(a)}</span><span>{H.escape(b)}</span><span>{H.escape(c)}</span></div>' for a,b,c in items)
    m = f'''<div class="split"><div class="doc" id="q1" style="width:820px;height:620px"><div class="tag">{H.escape(sc.get('tag','Quote'))}</div><div class="title">{H.escape(sc.get('title','Quote #1042, Smith residence'))}</div><div class="sub">{H.escape(sc.get('sub','Prepared for J. Smith, 42 Harbour Rd'))}</div>
      <div class="tbl"><div class="row h"><span>Item</span><span>Qty</span><span>Amount</span></div>{rows}</div>
      <div class="kv"><b>{H.escape(sc.get('total_label','Total inc. GST'))}</b><span>{H.escape(sc.get('total','$2,775'))}</span></div></div></div>'''
    j = f'''tl.fromTo('#q1', {{ opacity: 0, x: 900, rotateY: -10 }}, {{ opacity: 1, x: 0, rotateY: 0, duration: .7, ease: 'power4.out' }}, S{i} + .05);
document.querySelectorAll('#q1 .row').forEach((el,k) => tl.to(el, {{ opacity: 1, duration: .3 }}, S{i} + .55 + k*.1));
tl.to('#q1 .kv', {{ opacity: 1, duration: .3 }}, S{i} + .6 + {len(items)}*.1);'''
    return m, j, [('whoosh', .05, .45), ('pop', .6 + len(items)*.1, .5)]
SCENES = {'im': scene_im, 'emails': scene_emails, 'inbox': scene_inbox, 'voice_crm': scene_voice_crm, 'doc_pair': scene_doc_pair, 'quote': scene_quote}

# ------------------------------------------------------------------ timeline
open_d = cfg.get('open_seconds', 3.2); ask = cfg['ask']; cps = cfg.get('cps', 30)
type_start = open_d + 1.3; type_end = type_start + len(ask['text']) / cps; press = type_end + .7
ask_end = press + .55
outs = cfg['outputs']; t = ask_end; starts = []
for sc in outs: starts.append(t); t += sc.get('seconds', 2.0)
recall_start = t; recall_d = cfg.get('recall_seconds', 3.5); PR = recall_start + 2.45
turn_start = recall_start + recall_d; turn_d = cfg.get('turn_seconds', 3.6)
close_start = turn_start + turn_d; end = close_start + cfg.get('close_seconds', 2.1)
end = round(end, 2)

# ------------------------------------------------------------------ SFX (all optional: a missing file is skipped, the video still builds)
kb_src = os.path.join(HERE, 'assets', 'sfx', 'keyboard-source.mp3'); os.makedirs('assets/sfx', exist_ok=True)
kb_len = type_end - type_start + .15
have = set()
if os.path.exists(kb_src):
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-ss', '0', '-t', f'{kb_len:.3f}', '-i', kb_src, '-af', f'afade=t=in:st=0:d=0.05,afade=t=out:st={kb_len-.18:.3f}:d=0.18,volume=2.2', '-codec:a', 'libmp3lame', '-q:a', '3', 'assets/sfx/keys.mp3'], check=True)
    have.add('keys')
else:
    print('note: assets/sfx/keyboard-source.mp3 not found in the template, typing will be silent. Drop any 10s+ keyboard recording there.')
for f in ('pop', 'click', 'whoosh', 'chime'):
    src = os.path.join(HERE, 'assets', 'sfx', f + '.mp3')
    if os.path.exists(src): subprocess.run(['cp', src, f'assets/sfx/{f}.mp3'], check=True); have.add(f)
    else: print(f'note: {f}.mp3 missing from template/assets/sfx, that sound is skipped.')
for f in ('whitehorse-mark-white.png',):
    subprocess.run(['cp', os.path.join(HERE, 'assets', f), 'assets/' + f], check=True)
    subprocess.run(['cp', os.path.join(HERE, 'assets', f), 'assets/whitehorse-mark-white-end.png'], check=True)
DUR = {'pop': .72, 'click': .36, 'whoosh': .57, 'chime': 2.5, 'keys': round(kb_len, 3)}
sfx = [('click', press, .8), ('click', PR, .8), ('keys', type_start, .8), ('pop', open_d + .25 + 1.0, .5), ('pop', .4, .5),
       ('whoosh', recall_start + 1.7, .45), ('whoosh', turn_start - .4, .45), ('chime', recall_start + 3.1, .5), ('chime', close_start + .2, .5)]
sfx += [('pop', recall_start + .1 + k*.06, .3) for k in range(8)]

# ------------------------------------------------------------------ assemble
markup, js = [], []
for i, sc in enumerate(outs):
    m, j, s = SCENES[sc['type']](i, sc)
    markup.append(f'''  <div id="o{i}" class="scene"><div class="stage" id="o{i}-cam" data-layout-allow-overflow><div class="out">
    {headline(f"h{i}", sc["headline"])}
    {m}
  </div></div></div>''')
    nxt = starts[i+1] if i+1 < len(outs) else recall_start
    trans = f"blurX('#o{i}', '#s7', S{i}N - .25);" if i+1 == len(outs) else f"cut('#o{i}', '#o{i+1}', S{i}N);"
    js.append(f"/* ---- output {i}: {sc['type']} ---- */\nconst S{i} = {starts[i]:.3f}, S{i}N = {nxt:.3f};\n{j}\nwaterfall('#h{i} .w', S{i} + .45);\npush('#o{i}-cam', S{i} + .4, S{i}N - S{i} - .4);\n{trans}")
    for name, off, vol in s: sfx.append((name, starts[i] + off, vol))
sfx = [x for x in sfx if x[0] in have]
tags = '\n'.join(f'  <audio id="sfx{k:02d}" src="assets/sfx/{n}.mp3" data-start="{round(t,3)}" data-duration="{DUR[n]}" data-track-index="{9+(k%10)}" data-volume="{v}"></audio>' for k, (n, t, v) in enumerate(sfx))
minis = cfg.get('recall_cards')
if not minis:  # derive from the outputs: two cards per output, up to eight
    kinds = {'im': 'band', 'emails': '', 'inbox': '', 'voice_crm': 'wave', 'doc_pair': '', 'quote': 'grid'}
    minis = []
    for sc in outs:
        minis.append([sc['headline'].rstrip('.'), sc.get('address') or sc.get('title') or '', kinds.get(sc['type'], '')])
        minis.append([sc['headline'].rstrip('.'), '', ''])
    minis = minis[:8]
def mini(k, tag, title, kind):
    body = {'band': '<div class="band"></div>', 'grid': '<div class="grid"></div>', 'wave': '<div class="w">' + ''.join(f'<i style="height:{h}px"></i>' for h in (10,22,30,16,26,12,28,18,8,24,14)) + '</div>', '': '<div class="dl"></div><div class="dl s"></div>'}[kind]
    return f'<div class="mini" id="m{k+1}" data-layout-allow-occlusion data-layout-allow-overlap><div class="tag">{H.escape(tag)}</div>{"<div class=\"title\">"+H.escape(title)+"</div>" if title else ""}{body}<div class="dl"></div></div>'
ghost = f'<span class="ghost" aria-hidden="true">{H.escape(ask["text"])}<i class="cend" id="a1-end"></i></span>'
pills = ''.join(f'<div class="pill">{H.escape(p)}</div>' for p in cfg.get('pills', []))
K = dict(A_START=round(type_start,3), A_END=round(type_end,3), P=round(press,3), PR=round(PR,3))
T = dict(s2=open_d, s3=round(ask_end,3), s7=round(recall_start,3), s8=round(turn_start,3), s10=round(close_start,3), end=end)
page = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=1920, height=1080" />
<title>AI for {H.escape(client['name'])}</title>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/TextPlugin.min.js"></script>
<style>{style}</style>
</head>
<body>
<div id="root" data-composition-id="main" data-start="0" data-width="1920" data-height="1080" data-duration="{end}">
  <div id="bg"><div class="bloom" id="bloom-red"></div><div class="bloom" id="bloom-violet"></div><div class="bloom" id="bloom-red2"></div><div id="grain"></div></div>

  <div id="s1" class="scene"><div class="stage">{lockup('lk1', False, f'<div class="eyebrow" id="lk1-eye">{H.escape(cfg.get("eyebrow", "AI for " + client["name"]))}</div>')}</div></div>

  <div id="s2" class="scene"><div class="stage"><div class="ask">
    <div class="greet" id="a1-greet">{cfg.get('greeting', 'What do you need <u>done</u> today?')}</div>
    <div class="chatbar" id="a1-bar"><div class="line"><span id="a1-text"></span><span class="caret" id="a1-caret"></span>{ghost}</div>{send_btn('a1-send')}</div>
    <div class="pills" id="a1-pills">{pills}</div>
  </div></div></div>

{chr(10).join(markup)}

  <div id="s7" class="scene"><div class="stage"><div class="recall">
    {''.join(mini(k, *m) for k, m in enumerate(minis[:8]))}
    <div class="chatbar" id="rc-bar"><div class="line"><span class="ph">Ask for anything.</span></div>{send_btn('rc-send')}</div>
    <div class="reddot" id="reddot"></div>
  </div></div></div>

  <div id="s8" class="scene"><div class="stage">
    <div class="turn"><div class="big" id="h8">{''.join(f'<span class="w">{H.escape(w)}</span>' for w in cfg.get('turn_line','10x your output.').split())}</div><div class="rule" id="r8"></div><div class="small" id="sm8">{H.escape(cfg.get('turn_sub','What would you do with an hour back every day?'))}</div></div>
  </div></div>

  <div id="s10" class="scene"><div class="stage">{lockup('lk9', True)}</div></div>

  <svg id="cursor" viewBox="0 0 24 24" width="44" height="44"><path d="M4 2l16 9.5-7 1.6-3.6 6.4z" fill="#14100e" stroke="#fff" stroke-width="1.6" stroke-linejoin="round"/></svg>
  <div id="ripple"></div>
{tags}
  <div id="black"></div>
</div>
<script>
gsap.registerPlugin(TextPlugin);
const F = 1/30;
const tl = gsap.timeline({{ paused: true }});
const T = {json.dumps(T)};
const K = {json.dumps(K)};
{open(os.path.join(HERE, 'helpers.js')).read()}
/* ---------- 1 open ---------- */
waterfall('#lk1-eye', .4);
tl.set('#lk1-wm', {{ opacity: 1, y: 90, scale: .96 }}, .75);
tl.to('#lk1-wm', {{ y: 0, scale: 1, duration: .6, ease: 'power4.out' }}, .75);
tl.fromTo('#lk1-rule', {{ scaleX: 0 }}, {{ scaleX: 1, duration: .4, ease: 'power3.out' }}, 1.3);
waterfall('#lk1-with, #lk1-wh', 1.55);
tl.to('#lk1', {{ scale: 1.03, duration: T.s2 - 1.0, ease: 'power1.inOut' }}, 1.2);
gsap.set(['#lk1-eye','#lk1-wm','#lk1-with','#lk1-wh'], {{ opacity: 0 }});
blurX('#s1', '#s2', T.s2 - .1);

/* ---------- 2 ask ---------- */
gsap.set(['#a1-greet','#a1-bar','.pill'], {{ opacity: 0 }});
tl.fromTo('#a1-greet', {{ opacity: 0, y: 30 }}, {{ opacity: 1, y: 0, duration: .45, ease: 'power3.out' }}, T.s2 + .05);
tl.fromTo('#a1-bar', {{ opacity: 0, y: 90 }}, {{ opacity: 1, y: 0, duration: .5, ease: 'power3.out' }}, T.s2 + .15);
tl.to('.pill', {{ opacity: 1, duration: .3, stagger: .05, ease: 'power2.out' }}, T.s2 + .45);
blink('#a1-caret', T.s2 + .1, K.A_START);
let tA1 = typeInto('a1-text', {json.dumps(ask['text'])}, K.A_START, {cps});
tl.set('#a1-caret', {{ opacity: 1 }}, K.A_START);
blink('#a1-caret', tA1, T.s3);
clickSend('a1-send', K.P);
askCamera('#s2 .stage', 'a1-caret', 'a1-end', 'a1-send', K.A_START, K.A_END, K.P, false);
tl.to('#a1-text', {{ color: '#6b625c', duration: .25 }}, K.P + .1);
cut('#s2', '#o0', T.s3);

{chr(10).join(js)}

/* ---------- recall ---------- */
(function recall(){{
  const R = T.s7;
  const pos = [[-690,-300,-8],[-260,-330,-4],[230,-330,4],[690,-300,8],[-690,250,6],[-260,300,3],[230,300,-3],[690,250,-6]];
  pos.forEach((p,k) => {{
    const el = '#m'+(k+1); if (!document.querySelector(el)) return;
    tl.fromTo(el, {{ opacity: 0, x: 0, y: 0, scale: .3, rotate: 0 }}, {{ opacity: 1, x: p[0], y: p[1], scale: 1, rotate: p[2], duration: .7, ease: 'power3.out' }}, R + .05 + k*.06);
    tl.to(el, {{ x: 0, y: 0, scale: .04, rotate: p[2]*4, opacity: 0, duration: .5, ease: 'power3.in' }}, R + 1.7 + k*.07);
  }});
  clickSend('rc-send', K.PR);
  tl.to('#rc-bar', {{ scale: .06, opacity: 0, duration: .45, ease: 'power3.in' }}, R + 2.75);
  tl.to('#reddot', {{ opacity: 1, scale: 1, duration: .3, ease: 'back.out(1.6)' }}, R + 3.05);
}})();
tl.to('#s8', {{ clipPath: 'circle(1400px at 960px 540px)', duration: .6, ease: 'power3.in' }}, T.s8 - .4);
tl.set('#s7', {{ opacity: 0 }}, T.s8 + .2);
tl.to('#bg', {{ opacity: 0, duration: .3 }}, T.s8 + .1);

/* ---------- turn ---------- */
waterfall('#h8 .w', T.s8 + .35);
tl.to('#r8', {{ scaleX: 1, duration: .4, ease: 'power3.out' }}, T.s8 + .95);
tl.fromTo('#sm8', {{ opacity: 0, y: 26 }}, {{ opacity: 1, y: 0, duration: .5, ease: 'power3.out' }}, T.s8 + 1.15);
tl.fromTo('#s8 .turn', {{ scale: 1 }}, {{ scale: 1.03, duration: T.s10 - T.s8 - .4, ease: 'power1.inOut' }}, T.s8 + .4);
tl.to('#s8 .turn', {{ opacity: 0, y: -30, duration: .35, ease: 'power2.in' }}, T.s10 - .35);
tl.set('#s10', {{ opacity: 1 }}, T.s10 - .35);
tl.set('#s8', {{ opacity: 0 }}, T.s10);

/* ---------- close ---------- */
tl.set('#lk9-wm', {{ opacity: 1, y: 60 }}, T.s10);
tl.to('#lk9-wm', {{ y: 0, duration: .5, ease: 'power4.out' }}, T.s10);
tl.fromTo('#lk9-rule', {{ scaleX: 0 }}, {{ scaleX: 1, duration: .35, ease: 'power3.out' }}, T.s10 + .4);
waterfall('#lk9-with, #lk9-wh', T.s10 + .6);
gsap.set(['#lk9-wm','#lk9-with','#lk9-wh'], {{ opacity: 0 }});
tl.to('#black', {{ opacity: 1, duration: .5, ease: 'power2.in' }}, T.end - .5);

window.__timelines['main'] = tl;
</script>
</body>
</html>
'''
open('index.html', 'w').write(page)
if not os.path.exists('package.json'):
    for f in ('package.json', 'hyperframes.json'): subprocess.run(['cp', os.path.join(HERE, f), f])
    json.dump({"id": client['short'].lower().replace(' ', '-') + '-demo', "name": client['name'] + ' demo', "createdAt": "2026-01-01T00:00:00.000Z"}, open('meta.json', 'w'), indent=2)
print(f"built index.html: {end}s, ask {type_start:.2f}-{type_end:.2f}, click {press:.2f}, outputs at {[round(s,2) for s in starts]}, recall {recall_start:.2f}, turn {turn_start:.2f}, close {close_start:.2f}")
