---
workflow: general-video
flow: standard
format: 1920x1080
fps: 30
duration: <seconds>
audio: sfx-only
---
# <Client> demo video - brief

_Status: DRAFT, <date>. Awaiting Alex's sign-off before any build._

## One line
<Who watches, what they should feel, what the video shows, closing line.>

## Audience and job
| | |
|---|---|
| Who watches | |
| What it must do | |
| What it must not do | |
| Where it plays | |
| Sound | SFX only unless Alex says otherwise |

## Brand
- Client logo: <source URL, fill hex from the SVG>
- Accent: `#xxxxxx`
- Wordmark read: serif / sans

## Structure
| Time | Beat | Headline |
|---|---|---|
| 0-3 | Cold open lockup | |
| | Ask: "<text>" | |
| | Output 1 | |
| | ... | |
| | Recall | |
| | Turn | 10x your output. / subtitle |
| | Close | |

## Open questions for Alex
1.

## Build log
- <date>: 
