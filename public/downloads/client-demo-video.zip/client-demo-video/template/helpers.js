/* ---------- background ---------- */
(function blooms(){
  const r = document.getElementById('bloom-red'), v = document.getElementById('bloom-violet'), r2 = document.getElementById('bloom-red2');
  const d = { p: 0 };
  tl.fromTo([r,v,r2], { opacity: 0, scale: .8 }, { opacity: 1, scale: 1, duration: 1.6, ease: 'power2.out' }, 0);
  tl.to(d, { p: Math.PI*2*1.5, duration: T.s8, ease: 'none', onUpdate: () => {
    const s = 1 + Math.sin(d.p)*.04;
    r.style.transform  = `translate(${Math.sin(d.p)*40}px, ${Math.sin(d.p*1.3)*26}px) scale(${s})`;
    v.style.transform  = `translate(${Math.sin(d.p*1.3+1)*36}px, ${Math.sin(d.p+2)*30}px) scale(${2-s})`;
    r2.style.transform = `translate(${Math.sin(d.p*0.9+2)*60}px, ${Math.sin(d.p*1.2)*20}px) scale(${s})`;
  }}, 1.6);
})();

/* ---------- helpers ---------- */
function waterfall(sel, t0, opts={}){           // waterfall-entry: binary reveal + whip up
  const els = gsap.utils.toArray(sel); let t = t0;
  els.forEach((el,i) => {
    const heavy = i===0, dur = heavy ? .2 : .15, y = heavy ? 80 : 48;
    tl.set(el, { opacity: 1, y }, t);
    tl.to(el, { y: 0, duration: dur, ease: 'power4.out' }, t);
    t += dur - (i===0 ? 0 : F);
  });
  return t;
}
function blink(caret, t0, t1){                  // deterministic caret blink, finite steps
  const cycles = Math.max(0, Math.floor((t1 - t0) / .8) - 1);
  tl.set(caret, { opacity: 1 }, t0);
  tl.to(caret, { opacity: 0, duration: .4, ease: 'steps(1)', yoyo: true, repeat: cycles*2+1 }, t0);
}
function typeInto(id, text, t0, cps, prev=''){  // gsap-effects typewriter (TextPlugin); duration counts new chars only
  const dur = (text.length - prev.length) / cps;
  tl.to('#'+id, { text: { value: text }, duration: dur, ease: 'none' }, t0);
  return t0 + dur;
}
function press(sel, t0){                        // physics-press-reaction (no cursor)
  tl.to(sel, { scale: .88, duration: .1, ease: 'power1.in' }, t0);
  tl.to(sel, { scale: 1, duration: .32, ease: 'back.out(2.2)' }, t0 + .1);
}
function fillDoc(doc, t0, step=.07){            // progressive doc fill: heading, lines, blocks
  let t = t0;
  doc.querySelectorAll('.dh,.dl').forEach(el => { tl.to(el, { scaleX: 1, duration: .32, ease: 'power2.out' }, t); t += step; });
  doc.querySelectorAll('.img,.plan,.kv,.row,.clause').forEach(el => { tl.to(el, { opacity: 1, duration: .3, ease: 'power2.out' }, t); t += step; });
  return t;
}
function cut(fromSel, toSel, t){ tl.set(fromSel, { opacity: 0 }, t); tl.set(toSel, { opacity: 1 }, t); }
function blurX(fromSel, toSel, t){              // blur crossfade, 0.4s
  tl.to(fromSel, { opacity: 0, filter: 'blur(10px)', duration: .4, ease: 'power2.in' }, t);
  tl.fromTo(toSel, { opacity: 0, filter: 'blur(10px)' }, { opacity: 1, filter: 'blur(0px)', duration: .4, ease: 'power2.out' }, t);
}

function centerOf(el){                          // layout coords relative to #root, unaffected by preview scaling
  let x = el.offsetWidth/2, y = el.offsetHeight/2, n = el;
  while (n && n.id !== 'root'){ x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; }
  return { x, y };
}
function clickSend(sendId, pressAt){          // cursor-click-ripple (camera handled separately by camera())
  const btn = document.getElementById(sendId); const c = centerOf(btn);
  tl.set('#cursor', { x: c.x + 300, y: c.y + 220, opacity: 1, scale: 1 }, pressAt - .6);
  tl.to('#cursor', { x: c.x - 4, y: c.y - 2, duration: .5, ease: 'power3.out' }, pressAt - .6);
  tl.to(['#cursor', '#'+sendId], { scale: .86, duration: .08, ease: 'power2.in', yoyo: true, repeat: 1 }, pressAt);
  tl.set('#ripple', { x: c.x, y: c.y, xPercent: -50, yPercent: -50, opacity: 1, scale: 0 }, pressAt + .04);
  tl.to('#ripple', { scale: 3.2, opacity: 0, duration: .6, ease: 'power2.out', immediateRender: false }, pressAt + .04);
  tl.set('#cursor', { opacity: 0 }, pressAt + .34);
  return c;
}
// Virtual camera (viewport-change rule): ONE writer per stage. Zoom about a focus point that can travel.
// transform = translate(f*(1-S)) scale(S) with origin 0 0 keeps the focus point pinned on screen while zooming.
function camera(stageSel, keys){
  const st = document.querySelector(stageSel); st.style.transformOrigin = '0 0';
  const p = { S: 1, fx: 960, fy: 540 };
  const write = () => { st.style.transform = `translate(${p.fx*(1-p.S)}px, ${p.fy*(1-p.S)}px) scale(${p.S})`; };
  let prev = { S: 1, fx: keys[0].fx, fy: keys[0].fy };
  keys.forEach(k => {
    const to = { S: k.S, fx: k.fx, fy: k.fy };
    tl.fromTo(p, { ...prev }, { ...to, duration: k.dur, ease: k.ease || 'power2.inOut', onUpdate: write, immediateRender: false }, k.t);
    prev = to;
  });
}
// Typing follow + click punch for an ask scene: zoom onto the caret, ride it to the end of the text, release, then punch on the click.
function askCamera(stageSel, caretId, endId, sendId, typeStart, typeEnd, pressAt, releaseAfter){
  const c0 = centerOf(document.getElementById(caretId)), c1 = centerOf(document.getElementById(endId)), b = centerOf(document.getElementById(sendId));
  const Z = 1.5, P = 1.32;
  const keys = [
    { t: typeStart - .4, S: Z, fx: c0.x, fy: c0.y, dur: .55, ease: 'power2.inOut' },
    { t: typeStart + .15, S: Z, fx: c1.x, fy: c1.y, dur: Math.max(.2, typeEnd - typeStart - .15), ease: 'none' },
    { t: typeEnd + .1, S: 1, fx: c1.x, fy: c1.y, dur: .5, ease: 'power3.out' },
    { t: pressAt + .04, S: P, fx: b.x, fy: b.y, dur: .3, ease: 'power2.in' },
  ];
  if (releaseAfter) keys.push({ t: pressAt + .4, S: 1, fx: b.x, fy: b.y, dur: .5, ease: 'power3.out' });
  camera(stageSel, keys);
}
function push(camSel, t0, dur){ tl.fromTo(camSel, { scale: 1 }, { scale: 1.04, duration: dur, ease: 'power1.inOut' }, t0); }

