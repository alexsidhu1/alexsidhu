# Sound effects

The kit ships without audio so nothing here carries a third-party licence. Drop your own short MP3s in this folder and the generator picks them up by name:

| File | Used for | Length |
|---|---|---|
| keyboard-source.mp3 | typing (sliced to the exact run) | 10s or more of key taps |
| click.mp3 | the send button | under 0.5s |
| pop.mp3 | cards arriving | under 1s |
| whoosh.mp3 | slides and the vacuum | under 1s |
| chime.mp3 | ticks and the close | under 3s |

Any file that is missing is skipped. The video still builds.
Free sources: pixabay.com/sound-effects, freesound.org (check each licence).
