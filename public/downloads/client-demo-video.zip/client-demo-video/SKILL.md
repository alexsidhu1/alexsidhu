---
name: client-demo-video
description: Use when the user wants a demo, promo, or explainer video for a client or prospect that shows AI automating their admin (chat bar, typed request, outputs, closing card), a shorter cut of an existing demo, a client-agnostic reel for marketing, or edits to one of these (timing, sound, palette, new scene). Also use when a HyperFrames demo build needs sound effects synced to typing and clicks, a typing camera follow, or a cursor click zoom.
---

# Client demo video

## Overview

A chat-bar demo video is one pattern: cold-open lockup, someone types a plain-English request, clicks send, outputs appear, everything gets pulled back into the bar, then the closing line. This skill ships a generator (`template/build.py`) that produces the whole HyperFrames composition from a `config.json`, with sound effects and camera moves already correct. **Generate from the template. Never scaffold blank.**

Core principle: **one source of truth for time.** Scene windows, typing runs, click beats and every `<audio>` tag are computed from the same numbers in `build.py`. Hand-placed `data-start` values on sound effects drift within two edits.

## When to use

- "Make a demo video for [client]", "shorter version for Instagram", "make it 25 seconds", "change the background", "add a sound when..."
- A prospect video where the audience has never used a chat AI (no jargon, no model names on screen)
- NOT for talking-head footage, captions, or music-driven pieces (route via `/hyperframes`)

## Workflow

1. **Brief first, then approval.** Write `BRIEF.md` (copy `template/BRIEF.template.md`): audience, ask text, four to five outputs, palette, length. Get a yes before building; a wrong build costs more than the question.
2. **Pull the client brand from source.** Fetch their site's logo SVG and read the fill hex from it; that is the accent. Confirm a serif/sans read from the wordmark. Save the SVG into `assets/` and point `client.logo` at it. Fictional clients get a text wordmark instead (`client.wordmark`).
3. **Fill `config.json`** from `template/config.example.json`. Output scene types: `im` (document stack, `facts` configurable), `emails` (sorted inbox), `inbox` (triaged list with statuses), `voice_crm` (phone + CRM card), `doc_pair` (two documents), `quote` (line items + total, for trades/services). `recall_cards` is optional: leave it out and the generator derives up to eight cards from the outputs (two per output, so they repeat). Write your own list of four to eight `[tag, title, kind]` entries when you have the time; kinds are `band`, `grid`, `wave` or empty. Copy rules: no "Claude / ChatGPT / LLM / prompt" on screen, no real people, fictional addresses and companies.
4. **Build and gate**: `python3 <skill>/template/build.py config.json && npx hyperframes check`. Zero errors before anything else. Warnings about `composition_file_too_large` and transient crossfade overlaps are expected.
5. **Draft render and review**: `npx hyperframes render --quality draft --output renders/<name>-draft.mp4`, extract a contact sheet (`npx hyperframes snapshot --at ...`), send the draft for review. Verify sound landed with `ffmpeg -af volumedetect` at a click time and a silent stretch.
6. **High-quality render only after approval.** Keep the previous `index.html` as `index.vN.bak` when iterating so versions can be compared.
7. Log in the decision log and update `BRIEF.md`'s build log.

## Quick reference

| Need | Where |
|---|---|
| Change timing, add a scene, swap copy | `config.json`, then rebuild. Never edit `index.html` (overwritten) |
| New output type | Add a `scene_*` function to `SCENES` in `build.py`: returns (markup, js, sfx list) |
| Palette | `palette.accent` (+ `accent_soft`, `turn`, optional `bloom_secondary`) drives blooms, doc accents, turn slide. Cream canvas is fixed; tint the blooms, not the canvas |
| Keyboard sound | `template/assets/sfx/keyboard-source.mp3` is sliced to the typing run automatically. Use a real recording; synthesised key taps sound artificial |
| Camera on typing | `askCamera()` in `helpers.js`: zoom 1.5x onto the caret, ride it to the end of the text, release, punch 1.32x on click. Caret end position comes from the hidden `.ghost` span, measured with `offsetLeft` chains (transform-safe), not `getBoundingClientRect` |
| Recall (fan out and vacuum) | Up to eight `.mini` cards from `recall_cards`; the recall click has no zoom |

## Gotchas that cost a render

- **`fromTo` on a hidden element must set `opacity: 1` in the destination too** or cold render workers keep it invisible (`gsap_cold_seek_hidden_fromto_missing_reveal`). Sequential snapshots look fine, the encoded video does not.
- **Clip-path reveals trim anything outside the box.** Release with `tl.set(el, { clipPath: 'none' })` after the swipe, or badges on card corners get cut.
- **Every `<audio>` needs `id`, `data-duration`, and a track index.** Without duration the linter treats every clip as running to the end and floods `duplicate_audio_track`. Rotate track indexes for overlapping pops.
- **No CSS `transform` on an element GSAP tweens.** Centre ripples with `xPercent/yPercent: -50` in the tween.
- **Translucent white text on a colour fails AA.** Use a solid tint (`#fdf6f5` on violet).
- **Light accents fail contrast.** White text sits on `palette.turn` (close slides) and on `palette.accent` (group badges). Both need 4.5:1 against white, so a pale teal or gold will not do; `build.py` prints a WARNING with the ratio. Darken the colour, do not lighten the text.
- **Reading `check`:** the gate is the final `Check passed` line. Contrast lines marked with a cross inside a section that still says `0 error(s)` are warnings from transient frames; fix them when they name a static element (a lockup, a badge), ignore them when they only occur mid-transition. `duplicate_audio_track` on two overlapping pops is expected.
- **Bundled fonts only** for predictable renders: Inter, JetBrains Mono, Montserrat. Manrope fetches from Google at build time and fails closed in cloud renders.
- **Keyboard source is 10s.** Slices past the end come back short or empty; the generator starts at 0.
- **Check the click lands before the cut.** `build.py` asserts it; if you retime by hand you lose that.

## Taste notes

Hard cuts on ask-to-output reveals. Varied entrances per output (slide right, drop from top, rise from bottom, swipe, split from sides). Big click punch, keyboard sound, pop on arrivals, whoosh on slides, chime on ticks. No music unless asked. Closing pair: "10x your output." with "What would you do with an hour back every day?" as the subtitle, then the client-with-Whitehorse lockup, half-second fade to black.
