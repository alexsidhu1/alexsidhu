# Client demo video kit

A Claude Code skill plus a generator that turns a `config.json` into a finished
chat-bar demo video (HyperFrames + GSAP, 1920x1080, sound effects synced).

Install: unzip so that `SKILL.md` sits at `~/.claude/skills/client-demo-video/SKILL.md`.
Then in any empty folder: copy `template/config.example.json` to `config.json`, edit it, run

    python3 ~/.claude/skills/client-demo-video/template/build.py config.json
    npx hyperframes check
    npx hyperframes render --quality high --output demo.mp4

Or open Claude Code in that folder and say "make me a demo video for <client>". It reads the skill.

Needs: Node 20+, ffmpeg, Python 3. Optional: `npx hyperframes auth login` signs in to HeyGen for music, stock images, voices and cloud rendering; without it, local engines are used. The guide: alexsidhu.com/resources/making-videos-with-claude-code
Built by Alex Sidhu, Whitehorse AI. MIT licence for the kit; the Whitehorse mark stays ours.
